FILE: README.TXT

***************************************************************************
*                                                                         *
*                GoFlight Device Software Development Kit                 *
*                             Release 2.21	                              *
*                             May 16, 2012                                *
*       Copyright � GoFlight Inc. 1999-2012.  All rights reserved.        *
*                                                                         *
***************************************************************************

Introduction
------------
This is the Software Development Kit for GoFlight's lineup of flight
simulation hardware products including:

	* GF-45 Avionics Simulation Unit
	* GF-P8 pushbutton control module
	* GF-T8 toggle switch control module
	* GF-LGT landing gear and trim control module
	* GF-166 Versatile Radio Panel
	
New to version 2.00 of the SDK.

	* GF-46 Multi-Mode Display Module
	* GF-RP48 Rotary/Pushbutton/LED Module
	* GF-WCP Pro Warning Control Panel
	* GF-LGT II Landing Gear/Trim control module
	* GF-MCP Advanced Autopilot Module
	* GF-MCP Pro Mode Control Panel Module
	* GF-EFIS Control Panel Module
	* GF-TQ6 Throttle System
	* GF-ATC Headset Comms Panel
	* GF-SECM Single Engine Aircraft Control Module
	* GF-MESM Multi Engine Start Module
	* GF-FMC Flight Management Computer Module
	* GF-TPM Throttle/Prop/Mixture Control Module

New to version 2.10 of the SDK.

	* GF-DIO Digital Input / Output Board
	* These 2 functions were not being exported from GFDev.dll :- GF166_SetLDisplaySegments_stdcall and GF166_SetLDisplaySegments_stdcall

New to this version of the SDK (2.21).

	* These 2 functions were not being exported from GFDev.dll :- GFTQ6_GetNumDevices_stdcall and GFTQ6_GetNumDevices

What's Contained in this SDK
----------------------------
The SDK consists of the following.
These can be used to integrate support for GoFlight hardware into your own
software development projects.

GFDevApi.h
GFDev.dll
GFDev.lib
The above files are the Goflight software DLL and its import library.
Use this if you want to dynamically link the Goflight software using C/C++.

You can also use GFDev.dll with languages like Visual Basic etc.
Consult your programming language documents to see how to use DLLs with your programming language.

GFDevStatic.lib
The above file is a static version of the Goflight software.
Use this if you do no want to have a dependency on the Golfight software DLL.
This can only be used with C/C++

NOTE
As mentioned in the file, the following functions do nothing in this version of the SDK.
GFDIO_GetIndicators(...), GFDIO_GetBrightness(...) and GFDIO_SetBrightness(...)
If the DIO firmware is updated to support these functions, then the functions will be implemented in the SDK.
At the moment, these functions return GFDEV_ERR_FUNC_NOT_SUPPORTED.

Contact Information
-------------------
If you would like to provide feedback on this SDK or have technical
questions that go unanswered by the documentation and samples provided by
the kit, you can contact GoFlight by e-mail at techsupport@goflightinc.com.
Please also check our Web site for updated information regarding GoFlight
third-party developer support or SDKs.


